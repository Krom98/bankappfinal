package org.isge.bf.projet.bankapp.service;

import org.isge.bf.projet.bankapp.model.Transaction;

public interface TransactionService {
    Transaction addTransaction(Transaction transaction);
}
